function ambrosio_tortorelli(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); c4n = 2*(c4n-.5);
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
[nC,d] = size(c4n); nE = size(n4e,1); gg = g(c4n); 
alpha = 1; gamma = 10; tau = 2^(-red)/10; eps = 1/10;
[s,m,~] = fe_matrices(c4n,n4e); 
a_0 = zeros(nE,1);
phi = zeros(nC,1); corr = 1; eps_stop = 1e-2;
while corr > eps_stop
    a_phi_sq = eps^2+(sum(phi(n4e),2)/(d+1)).^2;
    [s_phi,~] = fe_matrices_weighted(c4n,n4e,a_phi_sq,a_0);
    X_u = gamma*m+alpha*s_phi;
    b_u = gamma*m*gg;
    u = X_u\b_u;    
    du = comp_gradient(c4n,n4e,u);
    mod_du_sq = sum(du.^2,2);
    [~,m_du] = fe_matrices_weighted(c4n,n4e,a_0,mod_du_sq);
    X_phi = m+eps*tau*s+tau*alpha*m_du+(1/(2*eps))*tau*m;
    b_phi = m*phi+(1/(2*eps))*tau*m*ones(nC,1);
    phi_new = X_phi\b_phi;
    dt_phi = (phi_new-phi)/tau;
    corr = sqrt(dt_phi'*m*dt_phi);
    phi = phi_new;
    figure(1); show_p1(c4n,n4e,Db,Nb,u); 
    figure(2); show_p1(c4n,n4e,Db,Nb,phi);
end

function val = g(x)
val = tanh(100*(sum(x.^2,2)-1/2));
