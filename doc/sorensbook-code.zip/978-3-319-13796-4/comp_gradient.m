function du = comp_gradient(c4n,n4e,u)
d = size(c4n,2); nE = size(n4e,1); 
du = zeros(nE,d);
for j = 1:nE
    X_T = [ones(1,d+1);c4n(n4e(j,:),:)'];
    grads_T = X_T\[zeros(1,d);eye(d)];
    du(j,:) = u(n4e(j,:))'*grads_T;          
end

