function tv_reg_regularized(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); c4n = c4n-.5;
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
h = 2^(-red); alpha = 100; tau = h/10; 
noise = .4; delta = h^(1/2);
nC = size(c4n,1); nE = size(n4e,1);
[~,m,~,~] = fe_matrices(c4n,n4e);
gg = g(c4n)+noise*(rand(nC,1)-.5);          
u = zeros(nC,1); 
corr = 1; eps_stop = 1e-5;  
while corr > eps_stop
    du = comp_gradient(c4n,n4e,u);
    a_du_inv = 1./sqrt(sum(du.^2,2)+delta^2);
    [s_du,~] = fe_matrices_weighted(c4n,n4e,a_du_inv,zeros(nE,1));
    X = (1+alpha*tau)*m+tau*s_du;
    b = m*u+tau*alpha*m*gg;
    u_new = X\b;
    dt_u = (u_new-u)/tau;
    corr = sqrt(dt_u'*m*dt_u);
    u = u_new;  
    show_p1(c4n,n4e,Db,Nb,u);
end

function val = g(x)
val = zeros(size(x,1),1);
val(sqrt(sum(x.^2,2))<.2) = 1;

function [s_a,m_b] = fe_matrices_weighted(c4n,n4e,a,b)
[nC,d] = size(c4n); nE = size(n4e,1);
m_loc = (ones(d+1,d+1)+eye(d+1))/((d+1)*(d+2));
ctr = 0; ctr_max = (d+1)^2*nE; 
I = zeros(ctr_max,1); J = zeros(ctr_max,1); 
X_s_a = zeros(ctr_max,1); X_m_b = zeros(ctr_max,1);
for j = 1:nE
    X_T = [ones(1,d+1);c4n(n4e(j,:),:)'];
    grads_T = X_T\[zeros(1,d);eye(d)];
    vol_T = det(X_T)/factorial(d);
    for m = 1:d+1
        for n = 1:d+1
            ctr = ctr+1;
            I(ctr) = n4e(j,m); J(ctr) = n4e(j,n);
            X_s_a(ctr) = vol_T*a(j)*grads_T(m,:)*grads_T(n,:)';
            X_m_b(ctr) = vol_T*b(j)*m_loc(m,n);
        end
    end
end
s_a = sparse(I,J,X_s_a,nC,nC); m_b = sparse(I,J,X_m_b,nC,nC);
