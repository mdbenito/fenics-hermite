function [c4n,n4e,Db,Nb] = triang_torus(r,R,red)
c4n_ref = [0,0;1,0;1,1;0,1]; n4e = [1,2,3;1,3,4]; 
Db = []; Nb = [];
for j = 1:red
    [c4n_ref,n4e,Db,Nb] = red_refine(c4n_ref,n4e,Db,Nb);
end
idx = find(c4n_ref(:,2)==1); c4n_ref(idx,2) = 0;
idx = find(c4n_ref(:,1)==1); c4n_ref(idx,1) = 0;
[c4n_ref,~,K] = unique(c4n_ref,'rows','first');
n4e = K(n4e); 
u = 2*pi*c4n_ref(:,1); v = 2*pi*c4n_ref(:,2);
c4n = [(R+r*cos(v)).*cos(u),(R+r*cos(v)).*sin(u),r*sin(v)];
