function [m,s,S,M_n,m_w,H] = willmore_matrices(c4n,n4e,w)
nC = size(c4n,1); nE = size(n4e,1);
max_ctr = 9*nE; ctr = 0;
I = zeros(max_ctr,1); J = zeros(max_ctr,1);
X_s = zeros(max_ctr,1);
diag_m = zeros(nC,1); 
diag_m_w = zeros(nC,1); 
diag_M_n = zeros(nC,3);
tr_nabla_w = zeros(nC,1); 
for j = 1:nE
    n_T = cross(c4n(n4e(j,2),:)-c4n(n4e(j,1),:),...
        c4n(n4e(j,3),:)-c4n(n4e(j,2),:));
    area_T = norm(n_T)/2;
    n_T = n_T/norm(n_T);
    mp_T = sum(c4n(n4e(j,:),:))/3;
    tmp_tetra = [c4n(n4e(j,:),:);mp_T+sqrt(area_T)*n_T];
    grads3_T = [1,1,1,1;tmp_tetra']\[0,0,0;eye(3)];
    P_T = eye(3)-n_T'*n_T;
    P_Dphi_T = grads3_T(1:3,:)*P_T;
    nabla_T_w = w(n4e(j,:),:)'*P_Dphi_T;
    tr_nabla_w(j) = trace(nabla_T_w);
    W_sq = sum(sum(nabla_T_w.^2));
    for k = 1:3
        diag_m(n4e(j,k)) = diag_m(n4e(j,k))+area_T/3;
        diag_m_w(n4e(j,k)) = diag_m_w(n4e(j,k))+area_T*W_sq/3;
        diag_M_n(n4e(j,k),:) = diag_M_n(n4e(j,k),:)...
            +(area_T/3)*n_T;
        for ell = 1:3
            ctr = ctr+1;
            I(ctr) = n4e(j,k); J(ctr) = n4e(j,ell); 
            X_s(ctr) = area_T...
                *(P_T*grads3_T(k,:)')'*(P_T*grads3_T(ell,:)');
        end
    end
end
m = spdiags(diag_m,0,nC,nC); m_w = spdiags(diag_m_w,0,nC,nC);
II = [3*I-2;3*I-1;3*I]; JJ = [3*J-2;3*J-1;3*J];
s = sparse(I,J,X_s); S = sparse(II,JJ,repmat(X_s,3,1));
I = [1:3:3*nC,2:3:3*nC,3:3:3*nC]'; J = [1:nC,1:nC,1:nC]';
M_n = sparse(I,J,diag_M_n(:)); 
H = average_quant_surf(c4n,n4e,tr_nabla_w);

