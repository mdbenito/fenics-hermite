#include <mex.h>
#include <math.h>
void new_grid_2d(double new_atoms[], double delta, double atoms[], 
		 int nr_old){
  int z, ctr, j, k, m, n, idx; idx = 16*nr_old;
  for (z=0; z<nr_old; z++){ctr = 0;
    for (j=0; j<2; j++) for (k=0; k<2; k++) 
      for (m=0; m<2; m++) for (n=0; n<2; n++){
	    new_atoms[0*idx+z*16+ctr] = atoms[0*nr_old+z]+j*delta;
	    new_atoms[1*idx+z*16+ctr] = atoms[1*nr_old+z]+k*delta;
	    new_atoms[2*idx+z*16+ctr] = atoms[2*nr_old+z]+m*delta;
	    new_atoms[3*idx+z*16+ctr] = atoms[3*nr_old+z]+n*delta;
	    ctr = ctr+1;}
}}
void new_grid_3d(double new_atoms[], double delta, double atoms[], 
		 int nr_old){
  int z,ctr, j, k, m, n, o, p, q, s, t, idx; idx = 512*nr_old;
  for (z=0;z<nr_old;z++){ctr = 0;
    for (j=0;j<2;j++) for (k=0;k<2;k++) for (m=0;m<2;m++) 
	  for (n=0;n<2;n++) for (o=0;o<2;o++) for (p=0;p<2;p++) 
	    for (q=0;q<2;q++) for (s=0;s<2;s++) for (t=0;t<2;t++){ 
		  new_atoms[0*idx+z*512+ctr] = atoms[0*nr_old+z]+j*delta;
		  new_atoms[1*idx+z*512+ctr] = atoms[1*nr_old+z]+k*delta;
		  new_atoms[2*idx+z*512+ctr] = atoms[2*nr_old+z]+m*delta;
		  new_atoms[3*idx+z*512+ctr] = atoms[3*nr_old+z]+n*delta;
		  new_atoms[4*idx+z*512+ctr] = atoms[4*nr_old+z]+o*delta;
		  new_atoms[5*idx+z*512+ctr] = atoms[5*nr_old+z]+p*delta;
		  new_atoms[6*idx+z*512+ctr] = atoms[6*nr_old+z]+q*delta;
		  new_atoms[7*idx+z*512+ctr] = atoms[7*nr_old+z]+s*delta;
		  new_atoms[8*idx+z*512+ctr] = atoms[8*nr_old+z]+t*delta;
		  ctr = ctr+1;}
}}
void mexFunction(int nlhs, mxArray *plhs[], 
        int nrhs, const mxArray *prhs[]){
  double *delta, *atoms, *new_atoms;
  int d, m, d_sq;
  if (nrhs!=3) mexErrMsgTxt("3 input arguments required!");
  if (nlhs!=1) mexErrMsgTxt("1 output argument required!");
  m = mxGetM(prhs[1]);
  delta = mxGetPr(prhs[0]);
  atoms = mxGetPr(prhs[1]);
  d = *mxGetPr(prhs[2]); d_sq = pow(d,2);
  plhs[0] = mxCreateDoubleMatrix(pow(2,d_sq)*m,d_sq,mxREAL);
  new_atoms = mxGetPr(plhs[0]);  
  if (d==2)
    new_grid_2d(new_atoms,*delta,atoms,m);
  else
    new_grid_3d(new_atoms,*delta,atoms,m);    
}



