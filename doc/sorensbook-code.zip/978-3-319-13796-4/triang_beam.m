function [c4n,n4e,Db,Nb] = triang_beam(d,L)
if d == 2
    c4n_ref = [0,0;1,0;1,1;0,1]; n4e_ref = [1,2,3;1,3,4]; 
    bdy_left = [4,1]; bdy_mid = [1,2;3,4]; bdy_right = [2,3];
elseif d == 3 
    c4n_ref = [0,0,0;0,0,1;0,1,0;0,1,1;1,0,0;1,0,1;1,1,0;1,1,1];
    n4e_ref = [1,2,8,4;1,2,6,8;1,3,4,8;1,3,8,7;1,5,7,8;1,5,8,6];
    bdy_left = [1,2,4;1,3,4]; bdy_right = [6,5,8;7,5,8];
    bdy_mid = [1,2,6;1,3,7;1,5,6;1,5,7;4,2,8;6,2,8;4,3,8;7,3,8];
end
nC = size(c4n_ref,1); c4n = c4n_ref; n4e = n4e_ref; 
bdy = [bdy_left;bdy_mid];
for k = 2:L
    c4n = [c4n;[c4n_ref(:,1)+(k-1),c4n_ref(:,2:d)]];
    n4e = [n4e;n4e_ref+nC*(k-1)];
    bdy = [bdy;bdy_mid+nC*(k-1)];
end
bdy = [bdy;bdy_right+nC*(L-1)];
[c4n,~,K] = unique(c4n,'rows','first');
n4e = K(n4e); bdy = K(bdy); Db = []; Nb = [];
for j = 1:size(bdy,1);
    mp_S = sum(c4n(bdy(j,:),:),1)/d;
    if (mp_S(1)<=3 && mp_S(d)==1) || (mp_S(1)>=2 && mp_S(d)==0)
        Db = [Db;bdy(j,:)];
    else
        Nb = [Nb;bdy(j,:)];
    end
end
