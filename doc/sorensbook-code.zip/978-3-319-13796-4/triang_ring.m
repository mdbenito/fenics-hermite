function [c4n,n4e,Db,Nb] = triang_ring(red)
c4n_ref = [0,0;1,0;1,1;0,1]; n4e = [1,2,3;1,3,4]; 
Db = [2,3;4,1]; Nb = [1,2;3,4]; 
for j = 1:red
    [c4n_ref,n4e,Db,Nb] = red_refine(c4n_ref,n4e,Db,Nb);
end
idx = find(c4n_ref(:,2)==1); c4n_ref(idx,2) = 0;
[c4n_ref,~,K] = unique(c4n_ref,'rows','first');
n4e = K(n4e); Db = K(Db); Nb = [];
r = c4n_ref(:,1); phi = c4n_ref(:,2);
c4n = [(r+1).*cos(2*pi*phi),(r+1).*sin(2*pi*phi)];
