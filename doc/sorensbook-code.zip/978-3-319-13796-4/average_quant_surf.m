function A_v = average_quant_surf(c4n,n4e,v)
nC = size(c4n,1); nE = size(n4e,1);
area_patch = zeros(nC,1); quant_patch = zeros(nC,1);
for j = 1:nE
    n_T = cross(c4n(n4e(j,2),:)-c4n(n4e(j,1),:),...
        c4n(n4e(j,3),:)-c4n(n4e(j,2),:));
    area_T = norm(n_T)/2;
    area_patch(n4e(j,:)) = area_patch(n4e(j,:))+area_T;
    quant_patch(n4e(j,:)) = quant_patch(n4e(j,:))+area_T*v(j);
end
A_v = quant_patch./area_patch;
