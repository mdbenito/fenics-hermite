#include <math.h>
#include <mex.h>
void grid_2d(double atoms[], double delta, int M, int N, int L){
  int j, k, m, n, idx;
  for (j=-M; j<M+1; j++) for (k=-M; k<M+1; k++)
    for (m=-M; m<M+1; m++) for (n=-M; n<M+1; n++){
	  idx = (j+M)*pow(N,3)+(k+M)*pow(N,2)+(m+M)*N+(n+M);
	  atoms[0*L+idx] = j*delta; atoms[1*L+idx] = k*delta;
	  atoms[2*L+idx] = m*delta; atoms[3*L+idx] = n*delta;}
}
void grid_3d(double atoms[], double delta, int M, int N, int L){
  int j, k, m, n, o, p, q, s, t, idx;
  for (j=-M; j<M+1; j++) for (k=-M; k<M+1; k++) 
    for (m=-M; m<M+1; m++) for (n=-M; n<M+1; n++) 
      for (o=-M; o<M+1; o++) for (p=-M; p<M+1; p++)
        for (q=-M; q<M+1; q++) for (s=-M; s<M+1; s++)
          for (t=-M; t<M+1; t++){
            idx = (j+M)*pow(N,8)+(k+M)*pow(N,7)+(m+M)*pow(N,6)
            +(n+M)*pow(N,5)+(o+M)*pow(N,4)+(p+M)*pow(N,3)
            +(q+M)*pow(N,2)+(s+M)*pow(N,1)+(t+M);
    		 atoms[0*L+idx] = j*delta; atoms[1*L+idx] = k*delta; 
             atoms[2*L+idx] = m*delta; atoms[3*L+idx] = n*delta; 
             atoms[4*L+idx] = o*delta; atoms[5*L+idx] = p*delta;
	     	 atoms[6*L+idx] = q*delta; atoms[7*L+idx] = s*delta; 
             atoms[8*L+idx] = t*delta;}
}
void mexFunction(int nlhs, mxArray *plhs[], 
        int nrhs, const mxArray *prhs[]){
  double *delta, *r, *atoms;
  int d, L, M, N;
  if (nrhs!=3) mexErrMsgTxt("3 input arguments required!");
  if (nlhs!=1) mexErrMsgTxt("1 output argument required!");
  delta  = mxGetPr(prhs[0]);
  r = mxGetPr(prhs[1]);
  d = *mxGetPr(prhs[2]);
  M = floor((*r)/(*delta));
  N = 2*M+1;
  L = pow(N,pow(d,2));
  plhs[0] = mxCreateDoubleMatrix(L,pow(d,2),mxREAL);  
  atoms =mxGetPr(plhs[0]);  
  if (d==2)
    grid_2d(atoms,*delta,M,N,L);
  else
    grid_3d(atoms,*delta,M,N,L);
}



