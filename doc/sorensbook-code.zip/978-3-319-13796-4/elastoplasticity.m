function elastoplasticity(d_tmp,red)
global d p_old p_new a_old a_new tau t; d = d_tmp;
[c4n,n4e,Db,Nb] = triang_beam(d,5);
shift_vec = [2.5,.5,.5];
c4n = 0.01*(c4n-ones(size(c4n,1),1)*shift_vec(1:d)); 
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
tau = 2^(-red)/40;
[nC,d] = size(c4n); nE = size(n4e,1);
T = .2; factor = 10; material_parameters(); 
p_old = zeros(nE,d^2); p_new = zeros(nE,d^2);
a_old = zeros(nE,1); a_new = zeros(nE,1); 
for k = 1:floor(T/tau)
    t = k*tau;
    [u,sigma] = plastic_step(c4n,n4e,Db,Nb);
    p_old = p_new; a_old = a_new;
    def = c4n+factor*reshape(u,d,nC)';
    mod_sigma = sum(sigma.^2,2).^(1/2);
    mod_p = sum(p_new.^2,2).^(1/2);
    figure(1); show_p1_def(c4n,n4e,def,mod_sigma); 
    figure(2); show_p1_def(c4n,n4e,def,mod_p); 
end

function [u,sigma] = plastic_step(c4n,n4e,Db,Nb)
[nC,d] = size(c4n); u = zeros(d*nC,1);
[B,W] = diri_constraint(c4n,Db);
[DF,F,sigma] = nonlinear_fe_matrices(c4n,n4e,Nb,u);
corr = 1; eps_stop = 1e-2;
while corr > eps_stop
    b = [DF*u-F;W];
    A = [DF,B';B,sparse(size(B,1),size(B,1))];
    x = A\b;
    u_new = x(1:d*nC);
    corr = sqrt((u-u_new)'*DF*(u-u_new))
    u = u_new;
    [DF,F,sigma] = nonlinear_fe_matrices_plast(c4n,n4e,Nb,u);
end

function material_parameters()
global nu lambda mu sigma_y H_kin H_iso;
E = 1.37e+11; nu = 0.3; 
lambda = nu*E/((1+nu)*(1-2*nu)); mu = E/(2*(1+nu)); 
sigma_y = 4.5e08; H_kin = 1/1000; H_iso = 0;
