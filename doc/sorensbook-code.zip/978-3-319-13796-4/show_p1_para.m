function show_p1_para(c4n,n4e,u)
nC = size(c4n,1);
trisurf(n4e,u(0*nC+(1:3:3*nC)),u(3*nC+(1:3:3*nC)),...
    u(6*nC+(1:3:3*nC)));
drawnow;