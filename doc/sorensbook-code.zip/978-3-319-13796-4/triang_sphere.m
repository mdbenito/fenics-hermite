function [n4e,c4n,Db,Nb] = triang_sphere(red)
c4n = [-1,-1,-1;1,-1,-1;1,1,-1;-1,1,-1;-1,-1,1;1,-1,1;...
    1,1,1;-1,1,1]/sqrt(3);
n4e = [1,2,6;6,5,1;2,3,7;7,6,2;3,8,7;3,4,8;4,5,8;4,1,5;...
    6,7,8;6,8,5;1,3,2;1,4,3];
Db = []; Nb = [];
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine_surf(c4n,n4e,Db,Nb);
    c4n = c4n./(sqrt(sum(c4n.^2,2))*[1,1,1]);
end
