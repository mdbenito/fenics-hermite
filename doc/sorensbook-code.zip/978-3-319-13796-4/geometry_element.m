function [mp_T,vol_T,grads_T] = geometry_element(Z_T)
d = size(Z_T,2);
mp_T = sum(Z_T,1)/(d+1);
X_T = [ones(1,d+1);Z_T'];
vol_T = det(X_T)/factorial(d);
grads_T = X_T\[zeros(1,d);eye(d)];
    