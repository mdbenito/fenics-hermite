function willmore_helfrich_flow(red)
[n4e,c4n,~,~] = triang_sphere(red);
c4n(:,3) = .4*c4n(:,3);
tau = 2^(-red)/200;
nC = size(c4n,1);  
w = averaged_normal(c4n,n4e);
[~,~,~,~,~,H] = willmore_matrices(c4n,n4e,w);
X = reshape(c4n',3*nC,1);
corr = 1; eps_stop = 1e-1;
while corr > eps_stop
    w = averaged_normal(c4n,n4e);    
    [m,s,S,M_n,m_w,~] = willmore_matrices(c4n,n4e,w);           
    m_H = spdiags(diag(m).*H.^2,0,nC,nC);    
    [lambda,mu] = helfrich_constraints(c4n,H,s,m,m_w,m_H);
    A = [M_n',tau*(s+m_H/2-max(lambda,0)*m);-S,M_n];
    b = [tau*m_w*H+M_n'*X+tau*(mu*m*ones(nC,1)...
        +min(lambda,0)*m*H);zeros(3*nC,1)];
    xx = A\b;
    V = (xx(1:3*nC)-X)/tau; 
    v = sum(reshape(V',3,nC)'.*w,2); 
    corr = sqrt(v'*m*v)
    H = xx(3*nC+(1:nC)); X = X+tau*V; c4n = reshape(X',3,nC)'; 
    show_p1_surf(c4n,n4e,H); 
end

function [lambda,mu] = helfrich_constraints(c4n,H,s,m,m_w,m_H)
nC = size(c4n,1); I = ones(nC,1);
mean_H = I'*m*H/(I'*m*I);
q = (H-mean_H)'*m*(H-mean_H);
lambda = 0;
if q > 0
    lambda = (-H'*m_w*H+H'*m_H/2*H...
        -(-H'*m_w*I+H'*m_H/2*I)*mean_H+H'*s*H)/q;
end
mu = (-H'*m_w*I+I'*m_H/2*H-lambda*I'*m*H)/(I'*m*I);

function w = averaged_normal(c4n,n4e)
nC = size(c4n,1); nE = size(n4e,1); 
n = zeros(nE,3); w = zeros(nC,3);
for j = 1:nE
    n_T = cross(c4n(n4e(j,2),:)-c4n(n4e(j,1),:),...
        c4n(n4e(j,3),:)-c4n(n4e(j,2),:));
    n(j,:) = n_T/norm(n_T);
end
for k = 1:3
    w(:,k) = average_quant_surf(c4n,n4e,n(:,k));
end
norm_w = sqrt(sum(w.^2,2));
w = w./(norm_w*ones(1,3));