function [B,W] = diri_constraint(c4n,Db)
[nC,d] = size(c4n); dNodes = unique(Db); nDb = size(dNodes,1);
B = sparse(d*nDb,d*nC); W = sparse(d*nDb,1);
for j = 1:nDb
    [M,U] = u_D(c4n(dNodes(j),:));
    B((j-1)*d+(1:d),(dNodes(j)-1)*d+(1:d)) = M;
    W((j-1)*d+(1:d)) = U;
end
essential_DNodes = find(sum(abs(B),2)); 
B = B(essential_DNodes,:); W = W(essential_DNodes,:);

function [M,U] = u_D(x) 
global t; d = size(x,2); M = zeros(d,d); U = zeros(d,1);
if x(d) == -0.005
    M = eye(d);
elseif x(d) == 0.005
    M(d,d) = 1; U(d) = -.002*t;
end


