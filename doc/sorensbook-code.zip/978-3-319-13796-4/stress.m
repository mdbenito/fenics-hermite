function val = stress(Du_T,j)  
global d lambda mu sigma_y H_kin H_iso;
global tau p_old p_new a_old a_new;
transp = reshape(1:d^2,d,d)';
id_mat = reshape(eye(d),1,d^2);
E_sym = (Du_T+Du_T(transp(:)))/2;
A = lambda*tr(E_sym-p_old(j,:))*id_mat+2*mu*(E_sym-p_old(j,:));
M = -H_kin*p_old(j,:);
r = 1+H_iso*sigma_y^2/mu+H_kin/mu;
s = sigma_y*(1-H_iso*a_old(j));
dt_p = zeros(1,d^2);
if norm(dev(A+M))-s > 0
    dt_p = (1/(2*mu*tau*r))*(1-s/norm(dev(A+M)))*dev(A+M);
end
p_new(j,:) = p_old(j,:)+tau*dt_p;
a_new(j) = a_old(j)-tau*sigma_y*norm(dt_p);
val = A-2*mu*tau*dt_p;

function dev_A = dev(A)
global d; dev_A = A-tr(A)/d*reshape(eye(d),1,d^2);
function tr_A = tr(A)
global d; tr_A = sum(A(1:d+1:d^2),2);
