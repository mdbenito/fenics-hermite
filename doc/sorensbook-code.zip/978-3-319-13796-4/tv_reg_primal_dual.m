function tv_reg_primal_dual(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); c4n = c4n-.5;
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
h = 2^(-red); alpha = 100; tau = h^(1/2)/10; noise = .4;
[s,m,~,~] = fe_matrices(c4n,n4e);
ms = mixed_matrix(c4n,n4e);
A = m+h*s; 
[nC,d] = size(c4n); nE = size(n4e,1); 
gg = g(c4n)+noise*(rand(nC,1)-.5); 
u = zeros(nC,1); u_tilde = u; p = zeros(nE,d); 
corr = 1; eps_stop = 1e-2;
while corr > eps_stop
    du_tilde = comp_gradient(c4n,n4e,u_tilde);
    p_tmp = p+tau*du_tilde;
    p = p_tmp./max(1,(sqrt(sum(p_tmp.^2,2))*ones(1,d))); 
    P = reshape(p',d*nE,1);
    u_new = (A+tau*alpha*m)\(A*u-tau*ms*P+tau*alpha*m*gg);
    dt_u = (u-u_new)/tau; 
    corr = sqrt(dt_u'*A*dt_u)
    u_tilde = 2*u_new-u; 
    u = u_new;
    show_p1(c4n,n4e,Db,Nb,u);
end

function ms = mixed_matrix(c4n,n4e)
[nC,d] = size(c4n); nE = size(n4e,1); 
ctr = 0; ctr_max = d*(d+1)*nE;
I = zeros(ctr_max,1); J = zeros(ctr_max,1); X = zeros(ctr_max,1);
for j = 1:nE
    X_T = [ones(1,d+1);c4n(n4e(j,:),:)'];
    grads_T = X_T\[zeros(1,d);eye(d)];
    vol_T = det(X_T)/factorial(d);
    for k = 1:d+1
        for ell = 1:d
            ctr = ctr+1;
            I(ctr) = n4e(j,k); J(ctr) = (j-1)*d+ell;
            X(ctr) = vol_T*grads_T(k,ell);
        end
    end
end
ms = sparse(I,J,X,nC,d*nE);

function val = g(x)
val = zeros(size(x,1),1);
val(sqrt(sum(x.^2,2))<.2) = 1;
