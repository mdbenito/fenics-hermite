function show_p1_def(c4n,n4e,def,mod_sigma)
[nC,d] = size(def);
if d == 1
    plot(c4n(n4e),def(n4e));
elseif d == 2
    trisurf(n4e,def(:,1),def(:,2),zeros(nC,1),mod_sigma); 
    view(0,90)
elseif d == 3
    tetramesh(n4e,def,mod_sigma);
end
drawnow;