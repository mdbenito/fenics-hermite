function nonlinear_elasticity(d_tmp,red)
global d; d = d_tmp; factor = 10;
[c4n,n4e,Db,Nb] = triang_beam(d,5);
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
[nC,d] = size(c4n); u = zeros(d*nC,1);
[B,W] = diri_constraint(c4n,Db);
[DF,F,sigma] = nonlinear_fe_matrices(c4n,n4e,Nb,u);
corr = 1; eps_stop = 1e-4;
while corr > eps_stop
    b = [DF*u-F;W]; A = [DF,B';B,sparse(size(B,1),size(B,1))];
    x = A\b; u_new = x(1:d*nC);
    corr = sqrt((u-u_new)'*DF*(u-u_new)); u = u_new;
    [DF,F,sigma] = nonlinear_fe_matrices(c4n,n4e,Nb,u);
end
def = c4n+factor*reshape(u,d,nC)';
mod_sigma = sum(sigma.^2,2).^(1/2);
show_p1_def(c4n,n4e,def,mod_sigma);

function [B,W] = diri_constraint(c4n,Db)
[nC,d] = size(c4n); dNodes = unique(Db); nDb = size(dNodes,1);
B = sparse(d*nDb,d*nC); W = sparse(d*nDb,1);
for j = 1:nDb
    [M,U] = u_D(c4n(dNodes(j),:));
    B((j-1)*d+(1:d),(dNodes(j)-1)*d+(1:d)) = M;
    W((j-1)*d+(1:d)) = U;
end
essential_DNodes = find(sum(abs(B),2)); 
B = B(essential_DNodes,:); W = W(essential_DNodes,:);

function [M,U] = u_D(x) 
d = size(x,2); M = zeros(d,d); U = zeros(d,1);
if x(d) == 0
    M = eye(d);
elseif x(d) == 1
    M(d,d) = 1; U(d) = -.025;
end

