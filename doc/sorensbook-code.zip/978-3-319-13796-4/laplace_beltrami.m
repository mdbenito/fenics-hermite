function laplace_beltrami(red)
[c4n,n4e,Db,Nb] = triang_torus(.5,1,red); 
nE = size(n4e,1); nC = size(c4n,1); 
nNb = size(Nb,1); nDb = size(Db,1);
dNodes = unique(Db); fNodes = setdiff(1:nC,dNodes);
max_ctr = 9*nE; ctr = 0;
I = zeros(max_ctr,1); J = zeros(max_ctr,1);
X_s = zeros(max_ctr,1);
b = zeros(nC,1); c = zeros(nC,1); u = zeros(nC,1);
for j = 1:nE
    n_T = cross(c4n(n4e(j,2),:)-c4n(n4e(j,1),:),...
        c4n(n4e(j,3),:)-c4n(n4e(j,2),:));
    area_T = norm(n_T)/2;
    n_T = n_T/norm(n_T);
    mp_T = sum(c4n(n4e(j,:),:))/3;
    aux_tetra = [c4n(n4e(j,:),:);mp_T+sqrt(area_T)*n_T];
    grads3_T = [1,1,1,1;aux_tetra']\[0,0,0;eye(3)];
    P_T = eye(3)-n_T'*n_T;
    for k = 1:3
        b(n4e(j,k)) = b(n4e(j,k))+(1/3)*area_T*f(mp_T);
        c(n4e(j,k)) = c(n4e(j,k))+(1/3)*area_T;
        for ell = 1:3
            ctr = ctr+1;
            I(ctr) = n4e(j,k); J(ctr) = n4e(j,ell); 
            X_s(ctr) = area_T*(P_T*grads3_T(k,:)')'...
                *(P_T*grads3_T(ell,:)');
        end
    end
end
s = sparse(I,J,X_s,nC,nC);
for j = 1:nNb
    length_E = norm(c4n(Nb(j,1),:)-c4n(Nb(j,2),:));
    mp_E = (c4n(Nb(j,1),:)-c4n(Nb(j,2),:))/2;
    b(Nb(j,1)) = b(Nb(j,1))+(1/2)*length_E*g(mp_E);
    b(Nb(j,2)) = b(Nb(j,2))+(1/2)*length_E*g(mp_E);
end
if isempty(dNodes)
    s = [s,c;c',0]; b = [b;0];
else
    for j = 1:nDb
        u(dNodes(j)) = u_D(c4n(dNodes(j),:));
    end
    b = b-s*u;
end
u(fNodes) = s(fNodes,fNodes)\b(fNodes);
show_p1_surf(c4n,n4e,u);

function val = f(X); val = X(2);
function val = u_D(X); val = 0;
function val = g(X); val = 0;


