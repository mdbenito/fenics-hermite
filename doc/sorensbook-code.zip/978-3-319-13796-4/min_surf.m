function min_surf(red,scheme)
[c4n,n4e,Db,Nb] = triang_ring(red); nC = size(c4n,1); 
[s,m,m_lumped] = fe_matrices(c4n,n4e); X_metric = s;
dNodes = unique(Db); fNodes = setdiff(1:nC,dNodes);
u = u_D(c4n); sd = zeros(nC,1);
pert = .01*(rand(nC,1)-.5); pert(dNodes) = 0; u = u+pert;
mu = 1/4; norm_corr = 1; eps_stop = 1e-4;
while norm_corr > eps_stop
    alpha = 1;
    if strcmp(scheme,'descent')
        [I_0,dI,~] = energy(c4n,n4e,u);
        sd(fNodes) = -X_metric(fNodes,fNodes)\dI(fNodes);
        [I_alpha,~] = energy(c4n,n4e,u+alpha*sd);
        armijo = I_alpha-I_0-mu*alpha*dI'*sd;
        while armijo > 0
            alpha = alpha/2;
            [I_alpha,~] = energy(c4n,n4e,u+alpha*sd);
            armijo = I_alpha-I_0-mu*alpha*dI'*sd;
        end
    elseif strcmp(scheme,'newton')
        [~,dI,d2I] = energy(c4n,n4e,u);
        sd(fNodes) = -d2I(fNodes,fNodes)\dI(fNodes);
    end
    u = u+alpha*sd; show_p1(c4n,n4e,Db,Nb,u);
    norm_corr = sqrt((alpha*sd)'*X_metric*(alpha*sd))
end

function [I,dI,d2I] = energy(c4n,n4e,u)
[nC,d] = size(c4n); nE = size(n4e,1); 
ctr_max = (d+1)^2*nE; ctr = 0;
I1 = zeros(ctr_max,1); I2 = zeros(ctr_max,1); 
X_d2I = zeros(ctr_max,1);
I = 0; dI = zeros(nC,1); 
for j = 1:nE
    grads_T = [1,1,1;c4n(n4e(j,:),:)']\[0,0;eye(2)];
    vol_T = det([1,1,1;c4n(n4e(j,:),:)'])/2;
    du = (grads_T)'*u(n4e(j,:)); mod_du = norm(du);
    I = I+vol_T*(1+mod_du^2)^(1/2);
    P_loc = ((1+mod_du^2).*eye(d)-du*du')./((1+mod_du^2)^(3/2));
    for k = 1:d+1
        dI(n4e(j,k)) = dI(n4e(j,k))...
            +vol_T*grads_T(k,:)*du/(1+mod_du^2);
        for ell = 1:d+1
            ctr = ctr+1; I1(ctr) = n4e(j,k); I2(ctr) = n4e(j,ell);
            X_d2I(ctr) = vol_T*(P_loc*grads_T(k,:)')'...
                *grads_T(ell,:)';
        end
    end
end
d2I = sparse(I1,I2,X_d2I);

function val = u_D(x)
val = .5*(2-sqrt(sum(x.^2,2)));