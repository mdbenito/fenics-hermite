function wave_maps(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); c4n = c4n-.5;
T = 10;
tau = 2^(-red)/4; K = ceil(T/tau);
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
nC = size(c4n,1);
[s,m,~,~] = fe_matrices(c4n,n4e);
SSS = sparse(3*nC,3*nC); MMM = sparse(3*nC,3*nC); 
for k = 1 : 3  
    idx = k:3:3*nC; SSS(idx,idx) = s; MMM(idx,idx) = m;
end
u = zeros(3*nC,1); v = zeros(3*nC,1);
for j = 1:nC
    u(3*j-[2,1,0]) = u_0(c4n(j,:));
    v(3*j-[2,1,0]) = v_0(c4n(j,:));
end
for k = 1:K
    B = sparse(nC,3*nC);
    for j = 1:nC
        B(j,3*j-[2,1,0]) = u(3*j-[2,1,0]);
    end
    X = [MMM+tau^2*SSS,B';B,sparse(nC,nC)];
    b = [MMM*v-tau*SSS*u;zeros(nC,1)];
    x = X\b;
    v = x(1:3*nC); 
    tu = u+tau*v;
    for j = 1:nC
        u(3*j-[2,1,0]) = tu(3*j-[2,1,0])/norm(tu(3*j-[2,1,0]));
    end
    show_p1_field(c4n,u); axis(.5*[-1,1,-1,1,-1,1]); 
    view(30,18); drawnow; pause(.05)
end

function val = u_0(x)
d = size(x,2);
x = [x,zeros(1,3-d)];
r = norm(x); a = max(0,1-2*r)^4;
val = [2*a*x(1:2),a^2-r^2 ]/(a^2+r^2);

function val = v_0(x)
val = [0,0,0];
