function [DF,F,sigma] = nonlinear_fe_matrices(c4n,n4e,Nb,u)
[nC,d] = size(c4n); nE = size(n4e,1); nNb = size(Nb,1);
F = zeros(d*nC,1); sigma = zeros(nE,d^2); Du = zeros(nE,d^2); 
ctr_max = d^2*(d+1)^2*nE; ctr = 0;
I = zeros(ctr_max,1); J = zeros(ctr_max,1); X = zeros(ctr_max,1);
for k = 1:d
    Du(:,(k-1)*d+(1:d)) = comp_gradient(c4n,n4e,u(k:d:nC*d));
end
for j = 1:nE
    [mp_T,vol_T,grads_T] = geometry_element(c4n(n4e(j,:),:));
    Du_T = Du(j,:); sigma(j,:) = stress(Du_T,j);
    for m = 1:d+1
        for p = 1:d
            D_psi_A = zeros(1,d^2); 
            D_psi_A(d*(p-1)+(1:d)) = grads_T(m,:);
            D_Sigma_T_A = stress_derivative(Du_T,D_psi_A,j);
            for n = 1:d+1
                for q = 1:d
                    ctr = ctr+1;
                    D_psi_B = zeros(1,d^2); 
                    D_psi_B(d*(q-1)+(1:d)) = grads_T(n,:);
                    I(ctr) = d*n4e(j,m)-d+p; 
                    J(ctr) = d*n4e(j,n)-d+q;
                    X(ctr) = vol_T*D_Sigma_T_A*D_psi_B'; 
            end; end            
            phi_mp_T = zeros(d,1); phi_mp_T(p) = 1/(d+1);
            F(d*(n4e(j,m)-1)+p) = F(d*(n4e(j,m)-1)+p) ... 
                +vol_T*(sigma(j,:)*D_psi_A'-f(mp_T)*phi_mp_T);
end; end; end
DF = sparse(I,J,X,d*nC,d*nC);
for j = 1:nNb
    [mp_S,vol_S] = geometry_side(c4n(Nb(j,:),:));
    for m = 1:d
        for p = 1:d
            phi_mp_S = zeros(d,1); phi_mp_S(p) = 1/d;
            F(d*(Nb(j,m)-1)+p) = F(d*(Nb(j,m)-1)+p)...
                -vol_S*g(mp_S)*phi_mp_S;
end; end; end

function val = f(x); global d; val = zeros(1,d);
function val = g(x); global d; val = zeros(1,d); 

function val = stress(Du_T,j)
global d; transp = reshape(1:d^2,d,d)';
E_sym = (Du_T+Du_T(transp(:)))/2;
val = .1*sum(E_sym.^2,2)*E_sym+E_sym;

function val = stress_derivative(Du_T,B,j)  
global d; transp = reshape(1:d^2,d,d)';
E_sym = (Du_T+Du_T(transp(:)))/2; B_sym = (B+B(transp(:)))/2;
val = .2*sum(E_sym.*B_sym,2)*E_sym+.1*sum(E_sym.^2,2)*B_sym+B_sym;
