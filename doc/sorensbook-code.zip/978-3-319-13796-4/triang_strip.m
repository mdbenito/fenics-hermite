function [c4n,n4e,Db,Nb] = triang_strip(L)
n4e = [[1:L;L+1+(2:L+1);L+1+(1:L)]';[1:L;2:L+1;L+1+(2:L+1)]'];
c4n = [[0:L;zeros(1,L+1)]';[0:L;ones(1,L+1)]'];
Db = [L+1,2*L+2;L+2,1];
Nb = [[1:L;2:L+1]';[2*L+2:-1:L+3;2*L+1:-1:L+2]'];
