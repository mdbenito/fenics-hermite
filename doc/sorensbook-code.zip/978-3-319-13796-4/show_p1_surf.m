function show_p1_surf(c4n,n4e,H)
trisurf(n4e,c4n(:,1),c4n(:,2),c4n(:,3),H); 
drawnow;