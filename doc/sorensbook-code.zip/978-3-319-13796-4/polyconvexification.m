function polyconvexification(d)
F_ref = [pi/4 0 0 0 0 0 0 0 0]; F = F_ref(1:d^2);
r = 4; L = 4; M = 100; 
W = @(F)(sum(F.^2,2)-1).^2;
[W_pc,lambda] = multilevel_poly(W,F,r,L,M)

function [W_pc,lambda] = multilevel_poly(W,F,r,L,M)
d = sqrt(size(F,2)); tau_d = (d-1)*d^2+1;
T_F = [F,minors(F)];
delta = r; atoms = grid_gen(delta,r,d);
W_pc = 0; lambda = zeros(tau_d,1); 
eps_as = 1; ell = 1;
while ell <= L
    W_A = feval(W,atoms); T_A = [atoms,minors(atoms)];
    mp = 0;
    while ~mp
        active = active_set(lambda,T_F,eps_as,T_A,W_A,delta,d);
        [lambda,W_pc] = lin_prog(T_F,active,T_A,W_A,tau_d);
        mp = max_princ(lambda,T_F,W_pc,delta,T_A,W_A);
        eps_as = eps_as*2;
    end
    if ell < L
        atoms = refine_coarsen(lambda,T_F,W_pc,T_A,W_A,delta,M,d);
        delta = delta/2; eps_as = delta; 
    end
    ell = ell+1;
end

function active = active_set(lambda,T_F,eps_as,T_A,W_A,delta,d)
nA = size(T_A,1);
vec = T_A*lambda-W_A;
active = sparse(size(T_A,1),1);
idx_mp = (vec>max(vec)-eps_as);
idx_feas = (max(abs(T_A(:,1:d^2)...
    -ones(nA,1)*T_F(1:d^2)),[],2)<=delta);
active(max(idx_mp,idx_feas)) = 1;

function [lambda,W_pc] = lin_prog(T_F,active,T_A,W_A,tau_d)
idx = find(active); n_active = nnz(idx);
f = W_A(idx)'; A = [T_A(idx,:),ones(n_active,1)]'; b = [T_F,1]';
[~,W_pc,~,~,Lambda] = linprog(f,[],[],A,b,zeros(n_active,1),[]);
lambda = -Lambda.eqlin(1:tau_d); 

function mp = max_princ(lambda,T_F,W_pc,delta,T_A,W_A)
vec_A = T_A*lambda-W_A;
mp = ~(max(vec_A)>T_F*lambda-W_pc+delta^2);

function atoms = refine_coarsen(lambda,T_F,W_pc,T_A,W_A,delta,M,d)
vec = T_A*lambda-W_A;
idx = (vec>T_F*lambda-W_pc-M*delta);
atoms = loc_grid_ref(delta/2,T_A(idx,1:d^2),d);
