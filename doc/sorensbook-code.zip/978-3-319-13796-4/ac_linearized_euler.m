function ac_linearized_euler(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); 
c4n = 2*(c4n-1/2);
for j = 1:red
    [c4n,n4e,Db,Nb,~,~] = red_refine(c4n,n4e,Db,Nb);
end
nC = size(c4n,1);
T = 1;
eps = 2^(-4); tau = (2/3)*eps^2;
K = ceil(T/tau);
u = u_0(c4n,eps);
[s,m,m_lumped] = fe_matrices(c4n,n4e); 
w_init = rand(nC,1)-.5;
lambda = zeros(K,1);
for k = 1:K
    b_nonlin = -eps^(-2)*m_lumped*f(u)...
        +eps^(-2)*m_lumped*(df(u).*u);
    m_nonlin = eps^(-2)*m_lumped*diag(df(u));
    b = tau^(-1)*m*u+b_nonlin;
    X = tau^(-1)*m+s+m_nonlin;
    u = X\b;
    c_shift = abs(min(df(u)))+1;
    Y = s+eps^(-2)*m_lumped*spdiags(df(u)+c_shift,0,nC,nC);
    [neg_lambda_shift,w] = vector_iteration(Y,m,w_init);
    lambda(k) = -neg_lambda_shift+eps^(-2)*c_shift;
    figure(1); show_p1(c4n,n4e,Db,Nb,u); axis square;
    figure(2); plot(tau*(1:k),lambda(1:k)); drawnow;
    w_init = w;
end

function val = f(u)
val = u.^3-u;
function val = df(u)
val = 3*u.^2-1;

function val = u_0(x,eps)
dist = sqrt(min((x(:,1)-.3).^2,(x(:,1)+.3).^2)+x(:,2).^2)-.35;
val = -tanh(dist/(sqrt(2)*eps));

function [mu,w] = vector_iteration(Y,m,w)
mu = 0; mu_old = 0; 
diff_mu = 1; eps_stop = 1E-01;
while abs(diff_mu) > eps_stop
    w = Y\(m*w);
    w = w/sqrt(w'*m*w);
    mu = w'*Y*w;
    diff_mu = mu-mu_old;
    mu_old = mu;
end
