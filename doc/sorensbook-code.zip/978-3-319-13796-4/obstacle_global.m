function obstacle_global(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); 
c4n = 3*(c4n-.5); Db = [Db;Nb]; Nb = [];
for j = 1 : red
    [c4n,n4e,Db,Nb,~,~] = red_refine(c4n,n4e,Db,Nb);
end
h = 2^(-red); tau = h/10;
nC = size(c4n,1); nE = size(n4e,1);
dNodes = unique(Db); fNodes = setdiff(1:nC,dNodes)';
[s,m,m_lumped,vol_T] = fe_matrices(c4n,n4e);
D = discrete_divergence(c4n,n4e);
u_old = u_D(c4n); u_new = zeros(nC,1);
p_old = zeros(nE,d); dt_p = zeros(nE,d);
norm_corr = 1; eps_stop = 1E-2;
while norm_corr > eps_stop
    p_tilde = p_old+tau*dt_p;
    div_p_tilde = m_lumped\(D'*reshape(p_tilde',d*nE,1));
    b = u_old+tau*(div_p_tilde+f(c4n));     
    u_new(fNodes) = max(chi(fNodes),b(fNodes));
    du_new = comp_gradient(c4n,n4e,u_new);
    p_new = (p_old+tau*du_new)/(1+tau);
    dt_p = (p_new-p_old)/tau; p_old = p_new; u_old = u_new;
    norm_corr = sqrt(vol_T'*sum(dt_p.^2,2))
end
show_p1(c4n,n4e,Db,Nb,u_old); drawnow;

function D = discrete_divergence(c4n,n4e)
[nC,d] = size(c4n); nE = size(n4e,1);
ctr = 0; ctr_max = d*(d+1)*nE;
I = zeros(ctr_max,1); J = zeros(ctr_max,1); 
X = zeros(ctr_max,1);
for j = 1 : nE
    X_T = [ones(1,d+1);c4n(n4e(j,:),:)'];
    grads_T = X_T\[zeros(1,d);eye(d)];
    vol_T = det(X_T)/factorial(d);
    for m = 1 : d+1
        for n = 1 : d
            ctr = ctr+1;
            I(ctr) = d*(j-1)+n; J(ctr) = n4e(j,m);
            X(ctr) = -vol_T*grads_T(m,n);
        end
    end    
end
D = sparse(I,J,X,d*nE,nC);

function val = f(x); val = -ones(size(x,1),1);
function val = u_D(x); val = zeros(size(x,1),1);
function val = chi(x); val = (-.15)*ones(size(x,1),1);