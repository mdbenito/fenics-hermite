function kirchhoff_nonlinear(red)
[c4n,n4e,Db,Nb] = triang_strip(10);
alpha = 1; tau = 2^(-red)/10;
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
nC = size(c4n,1); 
dNodes = unique(Db); DNodes = [3*dNodes-2;3*dNodes-1;3*dNodes-0];
FNodes = setdiff(1:9*nC,[0*nC+DNodes;3*nC+DNodes;6*nC+DNodes]);
S_dkt = fe_matrix_dkt(c4n,n4e);
[~,~,m_lumped] = fe_matrices(c4n,n4e);
Z = sparse(3*nC,3*nC);
SSS = [S_dkt,Z,Z;Z,S_dkt,Z;Z,Z,S_dkt];
SSS_free = SSS(FNodes,FNodes);
u = u_moebius(c4n);
dt_u = zeros(9*nC,1);
bbb = zeros(9*nC,1);
bbb(6*nC+(1:3:3*nC)) = m_lumped*f3(c4n);
corr = 1; eps_stop = 1e-2;
while corr > eps_stop;
    B = sparse(3*nC,9*nC);
    for j = 1:nC
        for k = 1:3
            idx_j = 3*(j-1); idx_jk = (k-1)*3*nC+3*(j-1);
            B(idx_j+1,idx_jk+2) = u(idx_jk+2);  
            B(idx_j+2,idx_jk+3) = u(idx_jk+3);
            B(idx_j+3,idx_jk+2) = u(idx_jk+3);
            B(idx_j+3,idx_jk+3) = u(idx_jk+2);
        end
    end
    B(DNodes,:) = [];
    ZZZ = sparse(size(B,1),size(B,1));
    AAA = [(1+tau*alpha)*SSS_free,B(:,FNodes)';B(:,FNodes),ZZZ];
    rhs = -alpha*SSS*u+bbb;
    ddd = [rhs(FNodes);zeros(size(B,1),1)];
    xxx = AAA\ddd;
    dt_u(FNodes) = xxx(1:size(SSS_free,1));
    corr = sqrt(dt_u'*SSS*dt_u)
    u = u+tau*dt_u; show_p1_para(c4n,n4e,u);
end

function val = f3(x)
val = 0*ones(size(x,1),1);

function u = u_moebius(x)
L = max(x(:,1)); nX = size(x,1); u = zeros(9*nX,1);
u(0*nX+(1:3:3*nX)) = sin(2*pi*x(:,1)/L);
u(3*nX+(1:3:3*nX)) = x(:,2)+(1-2*x(:,2)).*sin(pi*x(:,1)/(2*L));
u(6*nX+(1:3:3*nX)) = sin(pi*x(:,1)/L);
u(0*nX+(2:3:3*nX)) = ones(nX,1);
u(3*nX+(3:3:3*nX)) = ones(nX,1)-2*(x(:,1)>L/2).*ones(nX,1);
