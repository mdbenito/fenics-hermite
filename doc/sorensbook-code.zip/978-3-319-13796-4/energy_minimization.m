function energy_minimization(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); Db = [Db;Nb]; Nb = [];
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
[nC,d] = size(c4n); h = 2^(-red); 
dNodes = unique(Db); fNodes = setdiff(1:nC,dNodes);
[s,~,~,~] = fe_matrices(c4n,n4e); 
F = zeros(d,1); u = c4n*F+h*(rand(nC,1)-.5); 
u(dNodes) = c4n(dNodes,:)*F;
sd = zeros(nC,1); 
mu = 1/4; norm_corr = 1; eps_stop = 5e-4;
while norm_corr > eps_stop
    alpha = 1;
    [I_0,dI] = energy(c4n,n4e,u);
    sd(fNodes) = -s(fNodes,fNodes)\dI(fNodes);    
    [I_alpha,~] = energy(c4n,n4e,u+alpha*sd);
    armijo = I_alpha-I_0-mu*alpha*dI'*sd;
    while armijo > 0 
        alpha = alpha/2; 
        [I_alpha,~] = energy(c4n,n4e,u+alpha*sd);
        armijo = I_alpha-I_0-mu*alpha*dI'*sd;
    end
    u = u+alpha*sd;
    norm_corr = sqrt((alpha*sd)'*s*(alpha*sd))
    show_p1(c4n,n4e,Db,Nb,u); drawnow; 
end

function [I,dI] = energy(c4n,n4e,u)
[nC,d] = size(c4n); nE = size(n4e,1);
du = comp_gradient(c4n,n4e,u);
I = 0; dI = zeros(nC,1);
for j = 1:nE 
    X_T = [ones(1,d+1);c4n(n4e(j,:),:)'];
    grads_T = X_T\[zeros(1,d);eye(d)];
    vol_T = det(X_T)/factorial(d);
    [W_T,DW_T] = W(du(j,:));
    I = I+vol_T*W_T;
    for k = 1:d+1
        dI(n4e(j,k)) = dI(n4e(j,k))+vol_T*DW_T*grads_T(k,:)';
    end
end

function [val,vec] = W(F)
p = 32; phi = pi/4; F_ref = [cos(phi),sin(phi),0]; d = size(F,2);
F_1 = F_ref(1:d); F_2 = -F_1;
val = (1/p)*norm(F-F_1,2)^(p/2)*norm(F-F_2,2)^(p/2);
vec = (1/2)*norm(F-F_1,2)^(p/2-2)*norm(F-F_2,2)^(p/2)*(F-F_1)+...
  (1/2)*norm(F-F_1,2)^(p/2)*norm(F-F_2,2)^(p/2-2)*(F-F_2);