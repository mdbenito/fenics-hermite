function obstacle_newton(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); 
c4n = 3*(c4n-.5); Db = [Db;Nb]; Nb = [];
for j = 1:red
    [c4n,n4e,Db,Nb,P0,P1] = red_refine(c4n,n4e,Db,Nb);
end
nC = size(c4n,1); 
u_ini = zeros(nC,1);
dNodes = unique(Db); fNodes = setdiff(1:nC,dNodes)';
[s,m,m_lumped,vol_T] = fe_matrices(c4n,n4e);
[m_Nb,m_lumped_Nb] = fe_matrices_bdy(c4n,Nb);
u_ini(dNodes) = u_D(c4n(dNodes,:)); 
b = m*f(c4n)+m_Nb*g(c4n)-s*u_ini;
c = 1; I = speye(nC); tz = chi(c4n)-u_ini;
tu_old = zeros(nC,1); tu_new = zeros(nC,1); lambda = zeros(nC,1);
norm_corr = 1; eps_stop = 1E-3;
while norm_corr > eps_stop
    inactive = find(lambda+c*(tu_old-tz)>=0); 
    active = setdiff(1:nC,[inactive;dNodes]);
    o = sparse(size(active,2),size(active,2));
    X = [s(fNodes,fNodes),I(active,fNodes)';I(active,fNodes),o];
    x = X\[b(fNodes);tz(active)];
    tu_new(fNodes) = x(1:size(fNodes,1));
    corr = tu_new-tu_old;
    norm_corr = sqrt(corr'*s*corr);
    lambda = zeros(nC,1); 
    lambda(active) = x(size(fNodes,1)+(1:size(active,2)));
    tu_old = tu_new;
end
u = tu_new+u_ini;
show_p1(c4n,n4e,Db,Nb,u); drawnow; 

function val = chi(x); val = zeros(size(x,1),1);
function val = f(x); val = -2*ones(size(x,1),1);
function val = g(x); val = zeros(size(x,1),1);
function val = u_D(x); r = sqrt(sum(x.^2,2)); 
val = (r.^2/2-log(r)-1/2);
