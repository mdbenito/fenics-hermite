function perona_malik(d,red)
[c4n,n4e,Db,Nb] = triang_cube(d); c4n = 2*(c4n-.5);
lambda = .5;
for j = 1:red
    [c4n,n4e,Db,Nb] = red_refine(c4n,n4e,Db,Nb);
end
nE = size(n4e,1); 
tau = 2^(-red)/10; 
[~,m,~] = fe_matrices(c4n,n4e); 
u = g(c4n);
corr = 1; eps_stop = 1e-2;
while corr > eps_stop
    du = comp_gradient(c4n,n4e,u);
    a_du = (1+sum(du.^2,2)/lambda^2).^(-2); 
    [s_du,~] = fe_matrices_weighted(c4n,n4e,a_du,zeros(nE,1));
    X = m+tau*s_du;
    b = m*u;
    u_new = X\b;    
    dt_u = (u_new-u)/tau;
    u = u_new;
    corr = sqrt(dt_u'*m*dt_u);
    show_p1(c4n,n4e,Db,Nb,u); 
end

function val = g(x)
val = tanh(100*(sum(x.^2,2)-1/2))+.25*(rand(size(x,1),1)-.5);