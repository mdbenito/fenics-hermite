function val = stress_derivative(Du_T,Dv,j)  
global d lambda mu sigma_y H_kin H_iso;
global p_old a_old;
transp = reshape(1:d^2,d,d)';
id_mat = reshape(eye(d),1,d^2);
E_sym = (Du_T+Du_T(transp(:)))/2;
A = lambda*tr(E_sym-p_old(j,:))*id_mat+2*mu*(E_sym-p_old(j,:));
M = -H_kin*p_old(j,:);
r = 1+H_iso*sigma_y^2/mu+H_kin/mu;
s = sigma_y*(1-H_iso*a_old(j));
Dv_sym = (Dv+Dv(transp(:)))/2;
B = lambda*tr(Dv_sym)*id_mat+2*mu*Dv_sym;
val = B;
if norm(dev(A+M))-s > 0
    val = B+(1/r)*(norm(dev(A+M))-s)*dev(B)/norm(dev(A+M))...
        -(1/r)*s*(dev(A+M)*dev(B)')*dev(A+M)/norm(dev(A+M))^3;
end

function dev_A = dev(A)
global d; dev_A = A-tr(A)/d*reshape(eye(d),1,d^2);
function tr_A = tr(A)
global d; tr_A = sum(A(1:d+1:d^2),2);
